package com.example.tourmate;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.example.tourmate.Adapters.EventAdapter;
import com.example.tourmate.Adapters.ForcastAdapter;
import com.example.tourmate.DatabaseUtils.EventLoader;
import com.example.tourmate.Interface.EventObjectListiner;
import com.example.tourmate.Interface.LoadEventListiner;
import com.example.tourmate.PojoClass.Event;
import com.example.tourmate.PojoClass.EventDetails;
import com.example.tourmate.PojoClass.EventMember;
import com.example.tourmate.PojoClass.StaticData;
import com.example.tourmate.WeatherUtils.CurrentWeather.CurrentWeatherClient;
import com.example.tourmate.WeatherUtils.CurrentWeather.CurrentWeatherPojo.CurrentWeather;
import com.example.tourmate.WeatherUtils.CurrentWeather.CurrentWeatherService;
import com.example.tourmate.databinding.FragmentDashboardBinding;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;
    private ForcastAdapter adapter;
    private EventObjectListiner eventObjectListiner;


    private List<Event> eventList = new ArrayList<>();
    private List<EventMember> memberList = new ArrayList<>();
    private ProgressDialog dialog;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private DatabaseReference databaseReference;
    private DatabaseReference eventRef;
    public DashboardFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

         binding = DataBindingUtil.inflate(
                inflater, R.layout.fragment_dashboard, container, false);
        return binding.getRoot();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        dialog = new ProgressDialog(getActivity());
        auth = FirebaseAuth.getInstance();
        eventRef = FirebaseDatabase.getInstance().getReference().child("Event");
        user = auth.getCurrentUser();
        adapter = new ForcastAdapter();
        binding.forcastRecycler.setAdapter(adapter);
        binding.forcastRecycler.setLayoutManager(
                new LinearLayoutManager(getActivity(),
                        LinearLayoutManager.HORIZONTAL,false
                ));

        firebaseEventget();
        binding.eventSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(i !=0) {
                    getCurrentWeather(eventList.get(i - 1).getDetails().getEventAddress());

                    getCurrentBudgetProgress(i);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        binding.tempcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), EventActivity.class);

                intent.putExtra("frag", 1);

                StaticData.eventID = "NA";

                startActivity(intent);
            }
        });

    }

    private void getCurrentBudgetProgress(int i) {
        double budget = Double.parseDouble(eventList.get(i- 1).getDetails().getEventBudet());

        double expence = 100.00;

        double savings = budget - expence;

        binding.textView3.setText(String.valueOf(savings));

        double percentageDouble = (double)((savings/budget)*100.00);

        int percentage = (int) Math.round(percentageDouble);

        binding.textView5.setText(String.valueOf(percentage)+"%");
        binding.progressBar.setProgress(percentage);
    }

    private void firebaseEventget(){
        dialog.setMessage("Loading..");
        dialog.show();
        eventRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                eventList.clear();
                for(DataSnapshot d :dataSnapshot.getChildren()){
                    Event eventDetailsObj = d.getValue(Event.class);

                    memberList.clear();
                    for(DataSnapshot dd :d.child("MemberList").getChildren()){
                        EventMember member = dd.getValue(EventMember.class);
                        memberList.add(member);
                    }

                    if(memberList.toString().contains(user.getUid().toString())){
                        eventList.add(eventDetailsObj);
                    }

                }


                dialog.dismiss();
                if(eventList !=null) {
                    setspinner();
                   // Toast.makeText(getActivity(), eventList.toString(), Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                dialog.dismiss();
            }
        });

    }
    private void setspinner(){
        List<String> eventName =new ArrayList<>();
        eventName.add("Select Event");
        for(Event n:eventList){
            eventName.add(n.getDetails().getEventName());
        }
        ArrayAdapter<String> spinnerAdapter =
                new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,eventName);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        binding.eventSp.setAdapter(spinnerAdapter);
        if(eventName.size()>1){
            binding.eventSp.setSelection(1);
        }
    }
    private void getCurrentWeather(final String cityName){
        String baseUrl ="https://api.openweathermap.org/data/2.5/";
        CurrentWeatherService service = CurrentWeatherClient.getClient(
                baseUrl
        ).create(CurrentWeatherService.class);
        LatLng latLng = getLocationFromAddress(cityName);
        if(latLng !=null) {
            Log.i("LatLon", String.valueOf(latLng.latitude) + "," + String.valueOf(latLng.longitude));
            String endUrl = String.format("weather?lat=%f&lon=%f&units=metric&appid=%s", latLng.latitude, latLng.longitude, getString(R.string.currentWeatherApi));

            service.getCurrentWeather(endUrl)
                    .enqueue(new Callback<CurrentWeather>() {
                        @Override
                        public void onResponse(Call<CurrentWeather> call, Response<CurrentWeather> response) {
                            if (response.isSuccessful()) {
                                currentWeatherUIupdate(response.body(), cityName);
                            } else {
                                Toast.makeText(getActivity(), String.valueOf(response.code()), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<CurrentWeather> call, Throwable t) {

                        }
                    });
        }else {
            Toast.makeText(getActivity(), "Address not found", Toast.LENGTH_SHORT).show();
        }
    }
    private void currentWeatherUIupdate(CurrentWeather currentWeather,String cityname){
        binding.textView13.setText(currentWeather.getSys().getCountry()+","+cityname);
        binding.progressBar15.setProgress(currentWeather.getMain().getTemp().intValue());
        binding.textView9.setText(String.valueOf(
                currentWeather.getMain().getTemp().intValue()
        )+" °C");
        binding.textView11.setText(String.valueOf(
                currentWeather.getMain().getHumidity().intValue()
        )+" %");
        binding.progressBar14.setProgress(currentWeather.getMain().getHumidity().intValue());
        Picasso.get().load("https://openweathermap.org/img/w/"+currentWeather.getWeather().get(0).getIcon()+".png")
                .into(binding.imageView);

    }
    public LatLng getLocationFromAddress(String strAddress){

        Geocoder coder = new Geocoder(getActivity());
        List<Address> address;
        LatLng latLng ;

        try {
            address = coder.getFromLocationName(strAddress,5);
            if (address==null) {
                return null;
            }
          //  Toast.makeText(getActivity(), String.valueOf(address.size()), Toast.LENGTH_SHORT).show();
            if(address.size()>0) {
                Address location = address.get(0);
                double lat = location.getLatitude();
                double lon = location.getLongitude();
                latLng = new LatLng(lat, lon);
                return latLng;
            }else {
                return null;
            }


        } catch (IOException e) {
            Toast.makeText(getActivity(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            return null;
        }

    }



}
