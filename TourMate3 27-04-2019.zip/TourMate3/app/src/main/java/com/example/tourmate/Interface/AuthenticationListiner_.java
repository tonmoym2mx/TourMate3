package com.example.tourmate.Interface;

public interface AuthenticationListiner_ {
    void goToPtofile();
    void goToLogin();
    void goToSignUp();
}
