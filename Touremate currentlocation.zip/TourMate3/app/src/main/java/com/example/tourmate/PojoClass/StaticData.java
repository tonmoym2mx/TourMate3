package com.example.tourmate.PojoClass;

public class StaticData {
    public static String eventID;
}
