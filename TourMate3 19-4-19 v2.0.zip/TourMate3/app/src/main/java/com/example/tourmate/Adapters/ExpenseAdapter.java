package com.example.tourmate.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.tourmate.PojoClass.Expence;
import com.example.tourmate.R;

import java.util.List;

public class ExpenseAdapter extends RecyclerView.Adapter<ExpenceHolder> {
    private Context context;
    private List<Expence> expenceList;

    public ExpenseAdapter(Context context, List<Expence> expenceList) {
        this.context = context;
        this.expenceList = expenceList;
    }

    @NonNull
    @Override
    public ExpenceHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ExpenceHolder(
                LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_expence_recycler,parent,false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull ExpenceHolder holder, int position) {
        holder.costname.setText(expenceList.get(position).getExpenseName());
        holder.costTK.setText(expenceList.get(position).getCostName());
    }

    @Override
    public int getItemCount() {
        return expenceList.size();
    }
}
class ExpenceHolder extends RecyclerView.ViewHolder {

    TextView costname;
    TextView costTK;
    public ExpenceHolder(View itemView) {
        super(itemView);
        costname = itemView.findViewById(R.id.row_costName);
        costTK = itemView.findViewById(R.id.row_costTK);
    }
}
