package com.example.tourmate.Adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.tourmate.R;

public class ForcastAdapter extends RecyclerView.Adapter<ForcastHolder> {
    @NonNull
    @Override
    public ForcastHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ForcastHolder(
                LayoutInflater.from(parent.getContext())
                .inflate(R.layout.forcast_weather_row,parent,false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull ForcastHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 7;
    }
}
class ForcastHolder extends RecyclerView.ViewHolder {

    public ForcastHolder(View itemView) {
        super(itemView);
    }
}
