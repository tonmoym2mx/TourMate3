package com.example.tourmate.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.tourmate.EventActivity;
import com.example.tourmate.PojoClass.Event;
import com.example.tourmate.PojoClass.EventDetails;
import com.example.tourmate.PojoClass.StaticData;
import com.example.tourmate.R;

import java.text.SimpleDateFormat;
import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventHolder> {
    private Context context;
    private List<Event> eventList;

    public EventAdapter(Context context, List<Event> eventList) {
        this.context = context;
        this.eventList = eventList;
    }

    @NonNull
    @Override
    public EventHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new EventHolder(
                LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_recycler_row,parent,false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull EventHolder holder, final int position) {
        final EventDetails details = eventList.get(position).getDetails();
        holder.eventName.setText(details.getEventName());
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        String startdate = dateFormat.format(details.getEventStartDate().getTime());
        holder.startDate.setText(startdate);
        String enddate = dateFormat.format(details.getEventEndDate().getTime());
        holder.endDate.setText(enddate);
        holder.eventCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StaticData.eventID = details.getEventId();
                Intent intent = new Intent(context, EventActivity.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }
}
class EventHolder extends RecyclerView.ViewHolder {

    CardView eventCard;
    TextView eventName;
    TextView startDate;
    TextView endDate;
    TextView dayleft;
    public EventHolder(View itemView) {
        super(itemView);

        eventCard = itemView.findViewById(R.id.eventCard);
        eventName = itemView.findViewById(R.id.row_event_name);
        startDate = itemView.findViewById(R.id.row_envet_start_date);
        endDate = itemView.findViewById(R.id.row_event_end_date);
        dayleft = itemView.findViewById(R.id.row_event_days);

    }
}
