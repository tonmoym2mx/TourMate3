package com.example.tourmate.Adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.tourmate.R;

public class MomentAdapter extends RecyclerView.Adapter<MomentHolder> {
    @NonNull
    @Override
    public MomentHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MomentHolder(
                LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_moment_recycler,parent,false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull MomentHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 50;
    }
}
class MomentHolder extends RecyclerView.ViewHolder {

    public MomentHolder(View itemView) {
        super(itemView);
    }
}
