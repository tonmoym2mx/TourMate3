package com.example.tourmate.Adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.tourmate.PojoClass.Moment;
import com.example.tourmate.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MomentAdapter extends RecyclerView.Adapter<MomentHolder> {
    private List<Moment> momentList;
    public MomentAdapter(List<Moment> momentList) {
        this.momentList = momentList;
    }

    @NonNull
    @Override
    public MomentHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MomentHolder(
                LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_moment_recycler,parent,false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull MomentHolder holder, int position) {
        Moment moment = momentList.get(position);
        Picasso.get().load(moment.getMomentImg()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return momentList.size();
    }
}
class MomentHolder extends RecyclerView.ViewHolder {

    ImageView imageView;
    public MomentHolder(View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.momentImg);
    }
}
