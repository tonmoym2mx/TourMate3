package com.example.tourmate.Interface;

public interface OnTestInterface {
    void test();
}
