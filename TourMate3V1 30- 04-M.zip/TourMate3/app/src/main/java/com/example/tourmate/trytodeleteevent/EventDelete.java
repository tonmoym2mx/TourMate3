package com.example.tourmate.trytodeleteevent;

public class EventDelete {
    private static  Eventdeletelistiner eventdeletelistiner;

    public  Eventdeletelistiner getEventdeletelistiner() {
        return eventdeletelistiner;
    }

    public  void setEventdeletelistiner(Eventdeletelistiner eventdeletelistiner) {
        EventDelete.eventdeletelistiner = eventdeletelistiner;
    }
}
